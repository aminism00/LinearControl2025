# This program prints Hello, world!

print('Hello, world!')